/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.me;

/**
 *
 * @author sneha
 */
import java.io.*;
import java.util.Date;
import javax.servlet.http.*;
import javax.servlet.*;

public class JavaClass extends HttpServlet
{
     //implement service()
     public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException {
         res.setContentType("text/html");
         PrintWriter out = res.getWriter();
         Date dt = new Date();
         out.println("date" +dt.toString());
     }

}